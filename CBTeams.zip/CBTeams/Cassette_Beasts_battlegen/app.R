#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinyWidgets)
library(gridExtra)
library(png)
library(grid)
library(tidyverse)
library(tidyverse)
library(rvest)
BeastPage <- read_html("https://wiki.cassettebeasts.com/wiki/Species")
BeastTable <- html_table(html_nodes(BeastPage, "table"))[[1]]
BeastTable <- BeastTable[, -1]
BeastTable$Species[1] <- "Magikrab"
NameList <- BeastTable$Species

MovePage <- read_html("https://wiki.cassettebeasts.com/wiki/Moves")
Moves_table <- html_table(html_nodes(MovePage, "table"))[[1]]
Link <- 0

for (i in 1:141) {
  Link[i] <- paste("https://wiki.cassettebeasts.com/wiki/", NameList[i], sep="")}
MKPage <- read_html(Link[1])
MKMoves_table <- html_table(html_nodes(MKPage, "table"))
MKStats <- MKMoves_table[[3]]
MKMovesBase <- MKMoves_table[[5]]
MKMovesAllCompat <- MKMoves_table[[6]]
MKMovesAlways <- MKMoves_table[[7]]
MKMovesBootleg <- MKMoves_table[[8]]

colnames(MKMovesAllCompat) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MKMovesAllCompat <- MKMovesAllCompat[-1, ]

colnames(MKMovesAlways) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MKMovesAlways <- MKMovesAlways[-1, ]

colnames(MKMovesBootleg) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MKMovesBootleg <- MKMovesBootleg[-1, ]
MKMovesBootleg <- MKMovesBootleg[, -1]

Page1 <- read_html(Link[2])
Moves_table1 <- html_table(html_nodes(Page1, "table"))
Stats1 <- Moves_table1[[3]]
MovesBase1 <- Moves_table1[[5]]
MovesAllCompat1 <- Moves_table1[[6]]
MovesAlways1 <- Moves_table1[[7]]
MovesBootleg1 <- Moves_table1[[8]]

colnames(MovesAllCompat1) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat1 <- MovesAllCompat1[-1, ]

colnames(MovesAlways1) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways1 <- MovesAlways1[-1, ]

colnames(MovesBootleg1) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesBootleg1 <- MovesBootleg1[-1, ]

Page2 <- read_html(Link[3])
Moves_table2 <- html_table(html_nodes(Page2, "table"))
Stats1 <- Moves_table1[[3]]
MovesBase2 <- Moves_table2[[5]]
MovesAllCompat2 <- Moves_table2[[6]]
MovesAlways2 <- Moves_table2[[7]]
MovesBootleg2 <- Moves_table2[[8]]

colnames(MovesAllCompat2) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat2 <- MovesAllCompat2[-1, ]

colnames(MovesAlways2) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways2 <- MovesAlways2[-1, ]

colnames(MovesBootleg2) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesBootleg2 <- MovesBootleg2[-1, ]

Page3 <- read_html(Link[4])
Moves_table3 <- html_table(html_nodes(Page3, "table"))
Stats3 <- Moves_table3[[3]]
MovesBase3 <- Moves_table3[[5]]
MovesAllCompat3 <- Moves_table3[[6]]
MovesAlways3 <- Moves_table3[[7]]

colnames(MovesAllCompat3) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat3 <- MovesAllCompat3[-1, ]

colnames(MovesAlways3) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways3 <- MovesAlways3[-1, ]

Page4 <- read_html(Link[5])
Moves_table4 <- html_table(html_nodes(Page4, "table"))
Stats4 <- Moves_table4[[3]]
MovesBase4 <- Moves_table4[[5]]
MovesAllCompat4 <- Moves_table4[[6]]
MovesAlways4 <- Moves_table4[[7]]

colnames(MovesAllCompat4) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat4 <- MovesAllCompat4[-1, ]

colnames(MovesAlways4) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways4 <- MovesAlways4[-1, ]

Page5 <- read_html(Link[6])
Moves_table5 <- html_table(html_nodes(Page5, "table"))
Stats5 <- Moves_table5[[3]]
MovesBase5 <- Moves_table5[[5]]
MovesAllCompat5 <- Moves_table5[[6]]
MovesAlways5 <- Moves_table5[[7]]

colnames(MovesAllCompat5) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat5 <- MovesAllCompat5[-1, ]

colnames(MovesAlways5) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways5 <- MovesAlways5[-1, ]

Page6 <- read_html(Link[7])
Moves_table6 <- html_table(html_nodes(Page6, "table"))
Stats6 <- Moves_table6[[3]]
MovesBase6 <- Moves_table6[[5]]
MovesAllCompat6 <- Moves_table6[[6]]
MovesAlways6 <- Moves_table6[[7]]

colnames(MovesAllCompat6) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat6 <- MovesAllCompat6[-1, ]

colnames(MovesAlways6) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways6 <- MovesAlways6[-1, ]

Page7 <- read_html(Link[4])
Moves_table7 <- html_table(html_nodes(Page7, "table"))
Stats7 <- Moves_table7[[3]]
MovesBase7 <- Moves_table7[[5]]
MovesAllCompat7 <- Moves_table7[[6]]
MovesAlways7 <- Moves_table7[[7]]

colnames(MovesAllCompat7) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat7 <- MovesAllCompat7[-1, ]

colnames(MovesAlways7) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways7 <- MovesAlways7[-1, ]

Page8 <- read_html(Link[4])
Moves_table8 <- html_table(html_nodes(Page8, "table"))
Stats8 <- Moves_table8[[3]]
MovesBase8 <- Moves_table8[[5]]
MovesAllCompat8 <- Moves_table8[[6]]
MovesAlways8 <- Moves_table8[[7]]

colnames(MovesAllCompat8) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat8 <- MovesAllCompat8[-1, ]

colnames(MovesAlways8) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways8 <- MovesAlways8[-1, ]

Page9 <- read_html(Link[4])
Moves_table9 <- html_table(html_nodes(Page9, "table"))
Stats9 <- Moves_table9[[3]]
MovesBase9 <- Moves_table9[[5]]
MovesAllCompat9 <- Moves_table9[[6]]
MovesAlways9 <- Moves_table9[[7]]

colnames(MovesAllCompat9) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat9 <- MovesAllCompat9[-1, ]

colnames(MovesAlways9) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways9 <- MovesAlways9[-1, ]

Page10 <- read_html(Link[4])
Moves_table10 <- html_table(html_nodes(Page10, "table"))
Stats10 <- Moves_table10[[3]]
MovesBase10 <- Moves_table10[[5]]
MovesAllCompat10 <- Moves_table10[[6]]
MovesAlways10 <- Moves_table10[[7]]

colnames(MovesAllCompat10) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat10 <- MovesAllCompat10[-1, ]

colnames(MovesAlways10) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways10 <- MovesAlways10[-1, ]

Page11 <- read_html(Link[4])
Moves_table11 <- html_table(html_nodes(Page11, "table"))
Stats11 <- Moves_table11[[3]]
MovesBase11 <- Moves_table11[[5]]
MovesAllCompat11 <- Moves_table11[[6]]
MovesAlways11 <- Moves_table11[[7]]

colnames(MovesAllCompat11) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat11 <- MovesAllCompat11[-1, ]

colnames(MovesAlways11) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways11 <- MovesAlways11[-1, ]

Page12 <- read_html(Link[4])
Moves_table12 <- html_table(html_nodes(Page12, "table"))
Stats12 <- Moves_table12[[3]]
MovesBase12 <- Moves_table12[[5]]
MovesAllCompat12 <- Moves_table12[[6]]
MovesAlways12 <- Moves_table12[[7]]

colnames(MovesAllCompat12) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat12 <- MovesAllCompat12[-1, ]

colnames(MovesAlways12) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways12 <- MovesAlways12[-1, ]

Page13 <- read_html(Link[4])
Moves_table13 <- html_table(html_nodes(Page13, "table"))
Stats13 <- Moves_table13[[3]]
MovesBase13 <- Moves_table13[[5]]
MovesAllCompat13 <- Moves_table13[[6]]
MovesAlways13 <- Moves_table13[[7]]

colnames(MovesAllCompat13) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat13 <- MovesAllCompat13[-1, ]

colnames(MovesAlways13) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways13 <- MovesAlways13[-1, ]

Page14 <- read_html(Link[4])
Moves_table14 <- html_table(html_nodes(Page14, "table"))
Stats14 <- Moves_table14[[3]]
MovesBase14 <- Moves_table14[[5]]
MovesAllCompat14 <- Moves_table14[[6]]
MovesAlways14 <- Moves_table14[[7]]

colnames(MovesAllCompat14) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat14 <- MovesAllCompat14[-1, ]

colnames(MovesAlways14) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways14 <- MovesAlways14[-1, ]

Page15 <- read_html(Link[4])
Moves_table15 <- html_table(html_nodes(Page15, "table"))
Stats15 <- Moves_table15[[3]]
MovesBase15 <- Moves_table15[[5]]
MovesAllCompat15 <- Moves_table15[[6]]
MovesAlways15 <- Moves_table15[[7]]

colnames(MovesAllCompat15) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat15 <- MovesAllCompat15[-1, ]

colnames(MovesAlways15) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways15 <- MovesAlways15[-1, ]

Page16 <- read_html(Link[4])
Moves_table16 <- html_table(html_nodes(Page16, "table"))
Stats16 <- Moves_table16[[3]]
MovesBase16 <- Moves_table16[[5]]
MovesAllCompat16 <- Moves_table16[[6]]
MovesAlways16 <- Moves_table16[[7]]

colnames(MovesAllCompat16) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat16 <- MovesAllCompat16[-1, ]

colnames(MovesAlways16) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways16 <- MovesAlways16[-1, ]

Page17 <- read_html(Link[4])
Moves_table17 <- html_table(html_nodes(Page17, "table"))
Stats17 <- Moves_table17[[3]]
MovesBase17 <- Moves_table17[[5]]
MovesAllCompat17 <- Moves_table17[[6]]
MovesAlways17 <- Moves_table17[[7]]

colnames(MovesAllCompat17) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat17 <- MovesAllCompat17[-1, ]

colnames(MovesAlways17) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways17 <- MovesAlways17[-1, ]

Page18 <- read_html(Link[4])
Moves_table18 <- html_table(html_nodes(Page18, "table"))
Stats18 <- Moves_table18[[3]]
MovesBase18 <- Moves_table18[[5]]
MovesAllCompat18 <- Moves_table18[[6]]
MovesAlways18 <- Moves_table18[[7]]

colnames(MovesAllCompat18) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat18 <- MovesAllCompat18[-1, ]

colnames(MovesAlways18) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways18 <- MovesAlways18[-1, ]

Page19 <- read_html(Link[4])
Moves_table19 <- html_table(html_nodes(Page19, "table"))
Stats19 <- Moves_table19[[3]]
MovesBase19 <- Moves_table19[[5]]
MovesAllCompat19 <- Moves_table19[[6]]
MovesAlways19 <- Moves_table19[[7]]

colnames(MovesAllCompat19) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat19 <- MovesAllCompat19[-1, ]

colnames(MovesAlways19) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways19 <- MovesAlways19[-1, ]

Page20 <- read_html(Link[4])
Moves_table20 <- html_table(html_nodes(Page20, "table"))
Stats20 <- Moves_table20[[3]]
MovesBase20 <- Moves_table20[[5]]
MovesAllCompat20 <- Moves_table20[[6]]
MovesAlways20 <- Moves_table20[[7]]

colnames(MovesAllCompat20) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat20 <- MovesAllCompat20[-1, ]

colnames(MovesAlways20) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways20 <- MovesAlways20[-1, ]

Page21 <- read_html(Link[4])
Moves_table21 <- html_table(html_nodes(Page21, "table"))
Stats21 <- Moves_table21[[3]]
MovesBase21 <- Moves_table21[[5]]
MovesAllCompat21 <- Moves_table21[[6]]
MovesAlways21 <- Moves_table21[[7]]

colnames(MovesAllCompat21) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat21 <- MovesAllCompat21[-1, ]

colnames(MovesAlways21) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways21 <- MovesAlways21[-1, ]

Page22 <- read_html(Link[4])
Moves_table22 <- html_table(html_nodes(Page22, "table"))
Stats22 <- Moves_table22[[3]]
MovesBase22 <- Moves_table22[[5]]
MovesAllCompat22 <- Moves_table22[[6]]
MovesAlways22 <- Moves_table22[[7]]

colnames(MovesAllCompat22) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat22 <- MovesAllCompat22[-1, ]

colnames(MovesAlways22) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways22 <- MovesAlways22[-1, ]

Page23 <- read_html(Link[4])
Moves_table23 <- html_table(html_nodes(Page23, "table"))
Stats23 <- Moves_table23[[3]]
MovesBase23 <- Moves_table23[[5]]
MovesAllCompat23 <- Moves_table23[[6]]
MovesAlways23 <- Moves_table23[[7]]

colnames(MovesAllCompat23) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat23 <- MovesAllCompat23[-1, ]

colnames(MovesAlways23) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways23 <- MovesAlways23[-1, ]

Page24 <- read_html(Link[4])
Moves_table24 <- html_table(html_nodes(Page24, "table"))
Stats24 <- Moves_table24[[3]]
MovesBase24 <- Moves_table24[[5]]
MovesAllCompat24 <- Moves_table24[[6]]
MovesAlways24 <- Moves_table24[[7]]

colnames(MovesAllCompat24) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat24 <- MovesAllCompat24[-1, ]

colnames(MovesAlways24) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways24 <- MovesAlways24[-1, ]

Page25 <- read_html(Link[4])
Moves_table25 <- html_table(html_nodes(Page25, "table"))
Stats25 <- Moves_table25[[3]]
MovesBase25 <- Moves_table25[[5]]
MovesAllCompat25 <- Moves_table25[[6]]
MovesAlways25 <- Moves_table25[[7]]

colnames(MovesAllCompat25) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat25 <- MovesAllCompat25[-1, ]

colnames(MovesAlways25) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways25 <- MovesAlways25[-1, ]

Page26 <- read_html(Link[4])
Moves_table26 <- html_table(html_nodes(Page26, "table"))
Stats26 <- Moves_table26[[3]]
MovesBase26 <- Moves_table26[[5]]
MovesAllCompat26 <- Moves_table26[[6]]
MovesAlways26 <- Moves_table26[[7]]

colnames(MovesAllCompat26) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat26 <- MovesAllCompat26[-1, ]

colnames(MovesAlways26) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways26 <- MovesAlways26[-1, ]

Page27 <- read_html(Link[4])
Moves_table27 <- html_table(html_nodes(Page27, "table"))
Stats27 <- Moves_table27[[3]]
MovesBase27 <- Moves_table27[[5]]
MovesAllCompat27 <- Moves_table27[[6]]
MovesAlways27 <- Moves_table27[[7]]

colnames(MovesAllCompat27) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat27 <- MovesAllCompat27[-1, ]

colnames(MovesAlways27) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways27 <- MovesAlways27[-1, ]

Page28 <- read_html(Link[4])
Moves_table28 <- html_table(html_nodes(Page28, "table"))
Stats28 <- Moves_table28[[3]]
MovesBase28 <- Moves_table28[[5]]
MovesAllCompat28 <- Moves_table28[[6]]
MovesAlways28 <- Moves_table28[[7]]

colnames(MovesAllCompat28) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat28 <- MovesAllCompat28[-1, ]

colnames(MovesAlways28) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways28 <- MovesAlways28[-1, ]

Page29 <- read_html(Link[4])
Moves_table29 <- html_table(html_nodes(Page29, "table"))
Stats29 <- Moves_table29[[3]]
MovesBase29 <- Moves_table29[[5]]
MovesAllCompat29 <- Moves_table29[[6]]
MovesAlways29 <- Moves_table29[[7]]

colnames(MovesAllCompat29) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat29 <- MovesAllCompat29[-1, ]

colnames(MovesAlways29) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways29 <- MovesAlways29[-1, ]

Page30 <- read_html(Link[4])
Moves_table30 <- html_table(html_nodes(Page30, "table"))
Stats30 <- Moves_table30[[3]]
MovesBase30 <- Moves_table30[[5]]
MovesAllCompat30 <- Moves_table30[[6]]
MovesAlways30 <- Moves_table30[[7]]

colnames(MovesAllCompat30) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat30 <- MovesAllCompat30[-1, ]

colnames(MovesAlways30) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways30 <- MovesAlways30[-1, ]

Page31 <- read_html(Link[4])
Moves_table31 <- html_table(html_nodes(Page31, "table"))
Stats31 <- Moves_table31[[3]]
MovesBase31 <- Moves_table31[[5]]
MovesAllCompat31 <- Moves_table31[[6]]
MovesAlways31 <- Moves_table31[[7]]

colnames(MovesAllCompat31) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat31 <- MovesAllCompat31[-1, ]

colnames(MovesAlways31) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways31 <- MovesAlways31[-1, ]

Page32 <- read_html(Link[4])
Moves_table32 <- html_table(html_nodes(Page32, "table"))
Stats32 <- Moves_table32[[3]]
MovesBase32 <- Moves_table32[[5]]
MovesAllCompat32 <- Moves_table32[[6]]
MovesAlways32 <- Moves_table32[[7]]

colnames(MovesAllCompat32) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat32 <- MovesAllCompat32[-1, ]

colnames(MovesAlways32) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways32 <- MovesAlways32[-1, ]

Page33 <- read_html(Link[4])
Moves_table33 <- html_table(html_nodes(Page33, "table"))
Stats33 <- Moves_table33[[3]]
MovesBase33 <- Moves_table33[[5]]
MovesAllCompat33 <- Moves_table33[[6]]
MovesAlways33 <- Moves_table33[[7]]

colnames(MovesAllCompat33) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat33 <- MovesAllCompat33[-1, ]

colnames(MovesAlways33) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways33 <- MovesAlways33[-1, ]

Page34 <- read_html(Link[4])
Moves_table34 <- html_table(html_nodes(Page34, "table"))
Stats34 <- Moves_table34[[3]]
MovesBase34 <- Moves_table34[[5]]
MovesAllCompat34 <- Moves_table34[[6]]
MovesAlways34 <- Moves_table34[[7]]

colnames(MovesAllCompat34) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat34 <- MovesAllCompat34[-1, ]

colnames(MovesAlways34) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways34 <- MovesAlways34[-1, ]

Page35 <- read_html(Link[4])
Moves_table35 <- html_table(html_nodes(Page35, "table"))
Stats35 <- Moves_table35[[3]]
MovesBase35 <- Moves_table35[[5]]
MovesAllCompat35 <- Moves_table35[[6]]
MovesAlways35 <- Moves_table35[[7]]

colnames(MovesAllCompat35) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat35 <- MovesAllCompat35[-1, ]

colnames(MovesAlways35) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways35 <- MovesAlways35[-1, ]

Page36 <- read_html(Link[4])
Moves_table36 <- html_table(html_nodes(Page36, "table"))
Stats36 <- Moves_table36[[3]]
MovesBase36 <- Moves_table36[[5]]
MovesAllCompat36 <- Moves_table36[[6]]
MovesAlways36 <- Moves_table36[[7]]

colnames(MovesAllCompat36) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat36 <- MovesAllCompat36[-1, ]

colnames(MovesAlways36) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways36 <- MovesAlways36[-1, ]

Page37 <- read_html(Link[4])
Moves_table37 <- html_table(html_nodes(Page37, "table"))
Stats37 <- Moves_table37[[3]]
MovesBase37 <- Moves_table37[[5]]
MovesAllCompat37 <- Moves_table37[[6]]
MovesAlways37 <- Moves_table37[[7]]

colnames(MovesAllCompat37) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat37 <- MovesAllCompat37[-1, ]

colnames(MovesAlways37) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways37 <- MovesAlways37[-1, ]

Page38 <- read_html(Link[4])
Moves_table38 <- html_table(html_nodes(Page38, "table"))
Stats38 <- Moves_table38[[3]]
MovesBase38 <- Moves_table38[[5]]
MovesAllCompat38 <- Moves_table38[[6]]
MovesAlways38 <- Moves_table38[[7]]

colnames(MovesAllCompat38) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat38 <- MovesAllCompat38[-1, ]

colnames(MovesAlways38) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways38 <- MovesAlways38[-1, ]

Page39 <- read_html(Link[4])
Moves_table39 <- html_table(html_nodes(Page39, "table"))
Stats39 <- Moves_table39[[3]]
MovesBase39 <- Moves_table39[[5]]
MovesAllCompat39 <- Moves_table39[[6]]
MovesAlways39 <- Moves_table39[[7]]

colnames(MovesAllCompat39) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat39 <- MovesAllCompat39[-1, ]

colnames(MovesAlways39) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways39 <- MovesAlways39[-1, ]

Page40 <- read_html(Link[4])
Moves_table40 <- html_table(html_nodes(Page40, "table"))
Stats40 <- Moves_table40[[3]]
MovesBase40 <- Moves_table40[[5]]
MovesAllCompat40 <- Moves_table40[[6]]
MovesAlways40 <- Moves_table40[[7]]

colnames(MovesAllCompat40) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat40 <- MovesAllCompat40[-1, ]

colnames(MovesAlways40) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways40 <- MovesAlways40[-1, ]

Page41 <- read_html(Link[4])
Moves_table41 <- html_table(html_nodes(Page41, "table"))
Stats41 <- Moves_table41[[3]]
MovesBase41 <- Moves_table41[[5]]
MovesAllCompat41 <- Moves_table41[[6]]
MovesAlways41 <- Moves_table41[[7]]

colnames(MovesAllCompat41) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat41 <- MovesAllCompat41[-1, ]

colnames(MovesAlways41) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways41 <- MovesAlways41[-1, ]

Page42 <- read_html(Link[4])
Moves_table42 <- html_table(html_nodes(Page42, "table"))
Stats42 <- Moves_table42[[3]]
MovesBase42 <- Moves_table42[[5]]
MovesAllCompat42 <- Moves_table42[[6]]
MovesAlways42 <- Moves_table42[[7]]

colnames(MovesAllCompat42) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat42 <- MovesAllCompat42[-1, ]

colnames(MovesAlways42) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways42 <- MovesAlways42[-1, ]

Page43 <- read_html(Link[4])
Moves_table43 <- html_table(html_nodes(Page43, "table"))
Stats43 <- Moves_table43[[3]]
MovesBase43 <- Moves_table43[[5]]
MovesAllCompat43 <- Moves_table43[[6]]
MovesAlways43 <- Moves_table43[[7]]

colnames(MovesAllCompat43) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat43 <- MovesAllCompat43[-1, ]

colnames(MovesAlways43) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways43 <- MovesAlways43[-1, ]

Page44 <- read_html(Link[4])
Moves_table44 <- html_table(html_nodes(Page44, "table"))
Stats44 <- Moves_table44[[3]]
MovesBase44 <- Moves_table44[[5]]
MovesAllCompat44 <- Moves_table44[[6]]
MovesAlways44 <- Moves_table44[[7]]

colnames(MovesAllCompat44) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat44 <- MovesAllCompat44[-1, ]

colnames(MovesAlways44) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways44 <- MovesAlways44[-1, ]

Page45 <- read_html(Link[4])
Moves_table45 <- html_table(html_nodes(Page45, "table"))
Stats45 <- Moves_table45[[3]]
MovesBase45 <- Moves_table45[[5]]
MovesAllCompat45 <- Moves_table45[[6]]
MovesAlways45 <- Moves_table45[[7]]

colnames(MovesAllCompat45) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat45 <- MovesAllCompat45[-1, ]

colnames(MovesAlways45) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways45 <- MovesAlways45[-1, ]

Page46 <- read_html(Link[4])
Moves_table46 <- html_table(html_nodes(Page46, "table"))
Stats46 <- Moves_table46[[3]]
MovesBase46 <- Moves_table46[[5]]
MovesAllCompat46 <- Moves_table46[[6]]
MovesAlways46 <- Moves_table46[[7]]

colnames(MovesAllCompat46) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat46 <- MovesAllCompat46[-1, ]

colnames(MovesAlways46) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways46 <- MovesAlways46[-1, ]

Page47 <- read_html(Link[4])
Moves_table47 <- html_table(html_nodes(Page47, "table"))
Stats47 <- Moves_table47[[3]]
MovesBase47 <- Moves_table47[[5]]
MovesAllCompat47 <- Moves_table47[[6]]
MovesAlways47 <- Moves_table47[[7]]

colnames(MovesAllCompat47) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat47 <- MovesAllCompat47[-1, ]

colnames(MovesAlways47) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways47 <- MovesAlways47[-1, ]

Page48 <- read_html(Link[4])
Moves_table48 <- html_table(html_nodes(Page48, "table"))
Stats48 <- Moves_table48[[3]]
MovesBase48 <- Moves_table48[[5]]
MovesAllCompat48 <- Moves_table48[[6]]
MovesAlways48 <- Moves_table48[[7]]

colnames(MovesAllCompat48) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat48 <- MovesAllCompat48[-1, ]

colnames(MovesAlways48) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways48 <- MovesAlways48[-1, ]

Page49 <- read_html(Link[4])
Moves_table49 <- html_table(html_nodes(Page49, "table"))
Stats49 <- Moves_table49[[3]]
MovesBase49 <- Moves_table49[[5]]
MovesAllCompat49 <- Moves_table49[[6]]
MovesAlways49 <- Moves_table49[[7]]

colnames(MovesAllCompat49) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat49 <- MovesAllCompat49[-1, ]

colnames(MovesAlways49) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways49 <- MovesAlways49[-1, ]

Page50 <- read_html(Link[4])
Moves_table50 <- html_table(html_nodes(Page50, "table"))
Stats50 <- Moves_table50[[3]]
MovesBase50 <- Moves_table50[[5]]
MovesAllCompat50 <- Moves_table50[[6]]
MovesAlways50 <- Moves_table50[[7]]

colnames(MovesAllCompat50) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat50 <- MovesAllCompat50[-1, ]

colnames(MovesAlways50) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways50 <- MovesAlways50[-1, ]

Page51 <- read_html(Link[4])
Moves_table51 <- html_table(html_nodes(Page51, "table"))
Stats51 <- Moves_table51[[3]]
MovesBase51 <- Moves_table51[[5]]
MovesAllCompat51 <- Moves_table51[[6]]
MovesAlways51 <- Moves_table51[[7]]

colnames(MovesAllCompat51) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat51 <- MovesAllCompat51[-1, ]

colnames(MovesAlways51) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways51 <- MovesAlways51[-1, ]

Page52 <- read_html(Link[4])
Moves_table52 <- html_table(html_nodes(Page52, "table"))
Stats52 <- Moves_table52[[3]]
MovesBase52 <- Moves_table52[[5]]
MovesAllCompat52 <- Moves_table52[[6]]
MovesAlways52 <- Moves_table52[[7]]

colnames(MovesAllCompat52) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat52 <- MovesAllCompat52[-1, ]

colnames(MovesAlways52) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways52 <- MovesAlways52[-1, ]

Page53 <- read_html(Link[4])
Moves_table53 <- html_table(html_nodes(Page53, "table"))
Stats53 <- Moves_table53[[3]]
MovesBase53 <- Moves_table53[[5]]
MovesAllCompat53 <- Moves_table53[[6]]
MovesAlways53 <- Moves_table53[[7]]

colnames(MovesAllCompat53) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat53 <- MovesAllCompat53[-1, ]

colnames(MovesAlways53) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways53 <- MovesAlways53[-1, ]

Page54 <- read_html(Link[4])
Moves_table54 <- html_table(html_nodes(Page54, "table"))
Stats54 <- Moves_table54[[3]]
MovesBase54 <- Moves_table54[[5]]
MovesAllCompat54 <- Moves_table54[[6]]
MovesAlways54 <- Moves_table54[[7]]

colnames(MovesAllCompat54) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat54 <- MovesAllCompat54[-1, ]
colnames(MovesAlways54) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways54 <- MovesAlways54[-1, ]

Page55 <- read_html(Link[4])
Moves_table55 <- html_table(html_nodes(Page55, "table"))
Stats55 <- Moves_table55[[3]]
MovesBase55 <- Moves_table55[[5]]
MovesAllCompat55 <- Moves_table55[[6]]
MovesAlways55 <- Moves_table55[[7]]

colnames(MovesAllCompat55) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat55 <- MovesAllCompat55[-1, ]

colnames(MovesAlways55) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways55 <- MovesAlways55[-1, ]

Page56 <- read_html(Link[4])
Moves_table56 <- html_table(html_nodes(Page56, "table"))
Stats56 <- Moves_table56[[3]]
MovesBase56 <- Moves_table56[[5]]
MovesAllCompat56 <- Moves_table56[[6]]
MovesAlways56 <- Moves_table56[[7]]

colnames(MovesAllCompat56) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat56 <- MovesAllCompat56[-1, ]

colnames(MovesAlways56) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways56 <- MovesAlways56[-1, ]

Page57 <- read_html(Link[4])
Moves_table57 <- html_table(html_nodes(Page57, "table"))
Stats57 <- Moves_table57[[3]]
MovesBase57 <- Moves_table57[[5]]
MovesAllCompat57 <- Moves_table57[[6]]
MovesAlways57 <- Moves_table57[[7]]

colnames(MovesAllCompat57) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat57 <- MovesAllCompat57[-1, ]

colnames(MovesAlways57) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways57 <- MovesAlways57[-1, ]

Page58 <- read_html(Link[4])
Moves_table58 <- html_table(html_nodes(Page58, "table"))
Stats58 <- Moves_table58[[3]]
MovesBase58 <- Moves_table58[[5]]
MovesAllCompat58 <- Moves_table58[[6]]
MovesAlways58 <- Moves_table58[[7]]

colnames(MovesAllCompat58) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat58 <- MovesAllCompat58[-1, ]

colnames(MovesAlways58) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways58 <- MovesAlways58[-1, ]

Page59 <- read_html(Link[4])
Moves_table59 <- html_table(html_nodes(Page59, "table"))
Stats59 <- Moves_table59[[3]]
MovesBase59 <- Moves_table59[[5]]
MovesAllCompat59 <- Moves_table59[[6]]
MovesAlways59 <- Moves_table59[[7]]

colnames(MovesAllCompat59) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat59 <- MovesAllCompat59[-1, ]

colnames(MovesAlways59) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways59 <- MovesAlways59[-1, ]

Page60 <- read_html(Link[4])
Moves_table60 <- html_table(html_nodes(Page60, "table"))
Stats60 <- Moves_table60[[3]]
MovesBase60 <- Moves_table60[[5]]
MovesAllCompat60 <- Moves_table60[[6]]
MovesAlways60 <- Moves_table60[[7]]

colnames(MovesAllCompat60) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat60 <- MovesAllCompat60[-1, ]

colnames(MovesAlways60) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways60 <- MovesAlways60[-1, ]

Page61 <- read_html(Link[4])
Moves_table61 <- html_table(html_nodes(Page61, "table"))
Stats61 <- Moves_table61[[3]]
MovesBase61 <- Moves_table61[[5]]
MovesAllCompat61 <- Moves_table61[[6]]
MovesAlways61 <- Moves_table61[[7]]

colnames(MovesAllCompat61) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat61 <- MovesAllCompat61[-1, ]

colnames(MovesAlways61) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways61 <- MovesAlways61[-1, ]

Page62 <- read_html(Link[4])
Moves_table62 <- html_table(html_nodes(Page62, "table"))
Stats62 <- Moves_table62[[3]]
MovesBase62 <- Moves_table62[[5]]
MovesAllCompat62 <- Moves_table62[[6]]
MovesAlways62 <- Moves_table62[[7]]

colnames(MovesAllCompat62) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat62 <- MovesAllCompat62[-1, ]

colnames(MovesAlways62) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways62 <- MovesAlways62[-1, ]

Page63 <- read_html(Link[4])
Moves_table63 <- html_table(html_nodes(Page63, "table"))
Stats63 <- Moves_table63[[3]]
MovesBase63 <- Moves_table63[[5]]
MovesAllCompat63 <- Moves_table63[[6]]
MovesAlways63 <- Moves_table63[[7]]

colnames(MovesAllCompat63) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat63 <- MovesAllCompat63[-1, ]

colnames(MovesAlways63) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways63 <- MovesAlways63[-1, ]

Page64 <- read_html(Link[4])
Moves_table64 <- html_table(html_nodes(Page64, "table"))
Stats64 <- Moves_table64[[3]]
MovesBase64 <- Moves_table64[[5]]
MovesAllCompat64 <- Moves_table64[[6]]
MovesAlways64 <- Moves_table64[[7]]

colnames(MovesAllCompat64) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat64 <- MovesAllCompat64[-1, ]

colnames(MovesAlways64) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways64 <- MovesAlways64[-1, ]

Page65 <- read_html(Link[4])
Moves_table65 <- html_table(html_nodes(Page65, "table"))
Stats65 <- Moves_table65[[3]]
MovesBase65 <- Moves_table65[[5]]
MovesAllCompat65 <- Moves_table65[[6]]
MovesAlways65 <- Moves_table65[[7]]

colnames(MovesAllCompat65) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat65 <- MovesAllCompat65[-1, ]

colnames(MovesAlways65) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways65 <- MovesAlways65[-1, ]

Page66 <- read_html(Link[4])
Moves_table66 <- html_table(html_nodes(Page66, "table"))
Stats66 <- Moves_table66[[3]]
MovesBase66 <- Moves_table66[[5]]
MovesAllCompat66 <- Moves_table66[[6]]
MovesAlways66 <- Moves_table66[[7]]

colnames(MovesAllCompat66) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat66 <- MovesAllCompat66[-1, ]

colnames(MovesAlways66) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways66 <- MovesAlways66[-1, ]

Page67 <- read_html(Link[4])
Moves_table67 <- html_table(html_nodes(Page67, "table"))
Stats67 <- Moves_table67[[3]]
MovesBase67 <- Moves_table67[[5]]
MovesAllCompat67 <- Moves_table67[[6]]
MovesAlways67 <- Moves_table67[[7]]

colnames(MovesAllCompat67) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat67 <- MovesAllCompat67[-1, ]

colnames(MovesAlways67) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways67 <- MovesAlways67[-1, ]

Page68 <- read_html(Link[4])
Moves_table68 <- html_table(html_nodes(Page68, "table"))
Stats68 <- Moves_table68[[3]]
MovesBase68 <- Moves_table68[[5]]
MovesAllCompat68 <- Moves_table68[[6]]
MovesAlways68 <- Moves_table68[[7]]

colnames(MovesAllCompat68) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat68 <- MovesAllCompat68[-1, ]

colnames(MovesAlways68) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways68 <- MovesAlways68[-1, ]

Page69 <- read_html(Link[4])
Moves_table69 <- html_table(html_nodes(Page69, "table"))
Stats69 <- Moves_table69[[3]]
MovesBase69 <- Moves_table69[[5]]
MovesAllCompat69 <- Moves_table69[[6]]
MovesAlways69 <- Moves_table69[[7]]

colnames(MovesAllCompat69) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat69 <- MovesAllCompat69[-1, ]

colnames(MovesAlways69) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways69 <- MovesAlways69[-1, ]

Page70 <- read_html(Link[4])
Moves_table70 <- html_table(html_nodes(Page70, "table"))
Stats70 <- Moves_table70[[3]]
MovesBase70 <- Moves_table70[[5]]
MovesAllCompat70 <- Moves_table70[[6]]
MovesAlways70 <- Moves_table70[[7]]

colnames(MovesAllCompat70) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat70 <- MovesAllCompat70[-1, ]

colnames(MovesAlways70) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways70 <- MovesAlways70[-1, ]

Page71 <- read_html(Link[4])
Moves_table71 <- html_table(html_nodes(Page71, "table"))
Stats71 <- Moves_table71[[3]]
MovesBase71 <- Moves_table71[[5]]
MovesAllCompat71 <- Moves_table71[[6]]
MovesAlways71 <- Moves_table71[[7]]

colnames(MovesAllCompat71) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat71 <- MovesAllCompat71[-1, ]

colnames(MovesAlways71) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways71 <- MovesAlways71[-1, ]

Page72 <- read_html(Link[4])
Moves_table72 <- html_table(html_nodes(Page72, "table"))
Stats72 <- Moves_table72[[3]]
MovesBase72 <- Moves_table72[[5]]
MovesAllCompat72 <- Moves_table72[[6]]
MovesAlways72 <- Moves_table72[[7]]

colnames(MovesAllCompat72) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat72 <- MovesAllCompat72[-1, ]

colnames(MovesAlways72) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways72 <- MovesAlways72[-1, ]

Page73 <- read_html(Link[4])
Moves_table73 <- html_table(html_nodes(Page73, "table"))
Stats73 <- Moves_table73[[3]]
MovesBase73 <- Moves_table73[[5]]
MovesAllCompat73 <- Moves_table73[[6]]
MovesAlways73 <- Moves_table73[[7]]

colnames(MovesAllCompat73) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat73 <- MovesAllCompat73[-1, ]

colnames(MovesAlways73) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways73 <- MovesAlways73[-1, ]

Page74 <- read_html(Link[4])
Moves_table74 <- html_table(html_nodes(Page74, "table"))
Stats74 <- Moves_table74[[3]]
MovesBase74 <- Moves_table74[[5]]
MovesAllCompat74 <- Moves_table74[[6]]
MovesAlways74 <- Moves_table74[[7]]

colnames(MovesAllCompat74) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat74 <- MovesAllCompat74[-1, ]

colnames(MovesAlways74) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways74 <- MovesAlways74[-1, ]

Page75 <- read_html(Link[4])
Moves_table75 <- html_table(html_nodes(Page75, "table"))
Stats75 <- Moves_table75[[3]]
MovesBase75 <- Moves_table75[[5]]
MovesAllCompat75 <- Moves_table75[[6]]
MovesAlways75 <- Moves_table75[[7]]

colnames(MovesAllCompat75) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat75 <- MovesAllCompat75[-1, ]

colnames(MovesAlways75) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways75 <- MovesAlways75[-1, ]

Page76 <- read_html(Link[4])
Moves_table76 <- html_table(html_nodes(Page76, "table"))
Stats76 <- Moves_table76[[3]]
MovesBase76 <- Moves_table76[[5]]
MovesAllCompat76 <- Moves_table76[[6]]
MovesAlways76 <- Moves_table76[[7]]

colnames(MovesAllCompat76) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat76 <- MovesAllCompat76[-1, ]

colnames(MovesAlways76) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways76 <- MovesAlways76[-1, ]

Page77 <- read_html(Link[4])
Moves_table77 <- html_table(html_nodes(Page77, "table"))
Stats77 <- Moves_table77[[3]]
MovesBase77 <- Moves_table77[[5]]
MovesAllCompat77 <- Moves_table77[[6]]
MovesAlways77 <- Moves_table77[[7]]

colnames(MovesAllCompat77) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat77 <- MovesAllCompat77[-1, ]

colnames(MovesAlways77) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways77 <- MovesAlways77[-1, ]

Page78 <- read_html(Link[4])
Moves_table78 <- html_table(html_nodes(Page78, "table"))
Stats78 <- Moves_table78[[3]]
MovesBase78 <- Moves_table78[[5]]
MovesAllCompat78 <- Moves_table78[[6]]
MovesAlways78 <- Moves_table78[[7]]

colnames(MovesAllCompat78) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat78 <- MovesAllCompat78[-1, ]

colnames(MovesAlways78) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways78 <- MovesAlways78[-1, ]

Page79 <- read_html(Link[4])
Moves_table79 <- html_table(html_nodes(Page79, "table"))
Stats79 <- Moves_table79[[3]]
MovesBase79 <- Moves_table79[[5]]
MovesAllCompat79 <- Moves_table79[[6]]
MovesAlways79 <- Moves_table79[[7]]

colnames(MovesAllCompat79) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat79 <- MovesAllCompat79[-1, ]

colnames(MovesAlways79) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways79 <- MovesAlways79[-1, ]

Page80 <- read_html(Link[4])
Moves_table80 <- html_table(html_nodes(Page80, "table"))
Stats80 <- Moves_table80[[3]]
MovesBase80 <- Moves_table80[[5]]
MovesAllCompat80 <- Moves_table80[[6]]
MovesAlways80 <- Moves_table80[[7]]

colnames(MovesAllCompat80) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat80 <- MovesAllCompat80[-1, ]

colnames(MovesAlways80) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways80 <- MovesAlways80[-1, ]

Page81 <- read_html(Link[4])
Moves_table81 <- html_table(html_nodes(Page81, "table"))
Stats81 <- Moves_table81[[3]]
MovesBase81 <- Moves_table81[[5]]
MovesAllCompat81 <- Moves_table81[[6]]
MovesAlways81 <- Moves_table81[[7]]

colnames(MovesAllCompat81) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat81 <- MovesAllCompat81[-1, ]

colnames(MovesAlways81) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways81 <- MovesAlways81[-1, ]

Page82 <- read_html(Link[4])
Moves_table82 <- html_table(html_nodes(Page82, "table"))
Stats82 <- Moves_table82[[3]]
MovesBase82 <- Moves_table82[[5]]
MovesAllCompat82 <- Moves_table82[[6]]
MovesAlways82 <- Moves_table82[[7]]

colnames(MovesAllCompat82) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat82 <- MovesAllCompat82[-1, ]

colnames(MovesAlways82) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways82 <- MovesAlways82[-1, ]

Page83 <- read_html(Link[4])
Moves_table83 <- html_table(html_nodes(Page83, "table"))
Stats83 <- Moves_table83[[3]]
MovesBase83 <- Moves_table83[[5]]
MovesAllCompat83 <- Moves_table83[[6]]
MovesAlways83 <- Moves_table83[[7]]

colnames(MovesAllCompat83) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat83 <- MovesAllCompat83[-1, ]

colnames(MovesAlways83) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways83 <- MovesAlways83[-1, ]

Page84 <- read_html(Link[4])
Moves_table84 <- html_table(html_nodes(Page84, "table"))
Stats84 <- Moves_table84[[3]]
MovesBase84 <- Moves_table84[[5]]
MovesAllCompat84 <- Moves_table84[[6]]
MovesAlways84 <- Moves_table84[[7]]

colnames(MovesAllCompat84) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat84 <- MovesAllCompat84[-1, ]

colnames(MovesAlways84) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways84 <- MovesAlways84[-1, ]

Page85 <- read_html(Link[4])
Moves_table85 <- html_table(html_nodes(Page85, "table"))
Stats85 <- Moves_table85[[3]]
MovesBase85 <- Moves_table85[[5]]
MovesAllCompat85 <- Moves_table85[[6]]
MovesAlways85 <- Moves_table85[[7]]

colnames(MovesAllCompat85) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat85 <- MovesAllCompat85[-1, ]

colnames(MovesAlways85) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways85 <- MovesAlways85[-1, ]

Page86 <- read_html(Link[4])
Moves_table86 <- html_table(html_nodes(Page86, "table"))
Stats86 <- Moves_table86[[3]]
MovesBase86 <- Moves_table86[[5]]
MovesAllCompat86 <- Moves_table86[[6]]
MovesAlways86 <- Moves_table86[[7]]

colnames(MovesAllCompat86) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat86 <- MovesAllCompat86[-1, ]

colnames(MovesAlways86) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways86 <- MovesAlways86[-1, ]

Page87 <- read_html(Link[4])
Moves_table87 <- html_table(html_nodes(Page87, "table"))
Stats87 <- Moves_table87[[3]]
MovesBase87 <- Moves_table87[[5]]
MovesAllCompat87 <- Moves_table87[[6]]
MovesAlways87 <- Moves_table87[[7]]

colnames(MovesAllCompat87) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat87 <- MovesAllCompat87[-1, ]

colnames(MovesAlways87) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways87 <- MovesAlways87[-1, ]

Page88 <- read_html(Link[4])
Moves_table88 <- html_table(html_nodes(Page88, "table"))
Stats88 <- Moves_table88[[3]]
MovesBase88 <- Moves_table88[[5]]
MovesAllCompat88 <- Moves_table88[[6]]
MovesAlways88 <- Moves_table88[[7]]

colnames(MovesAllCompat88) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat88 <- MovesAllCompat88[-1, ]

colnames(MovesAlways88) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways88 <- MovesAlways88[-1, ]

Page89 <- read_html(Link[4])
Moves_table89 <- html_table(html_nodes(Page89, "table"))
Stats89 <- Moves_table89[[3]]
MovesBase89 <- Moves_table89[[5]]
MovesAllCompat89 <- Moves_table89[[6]]
MovesAlways89 <- Moves_table89[[7]]

colnames(MovesAllCompat89) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat89 <- MovesAllCompat89[-1, ]

colnames(MovesAlways89) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways89 <- MovesAlways89[-1, ]

Page90 <- read_html(Link[4])
Moves_table90 <- html_table(html_nodes(Page90, "table"))
Stats90 <- Moves_table90[[3]]
MovesBase90 <- Moves_table90[[5]]
MovesAllCompat90 <- Moves_table90[[6]]
MovesAlways90 <- Moves_table90[[7]]

colnames(MovesAllCompat90) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat90 <- MovesAllCompat90[-1, ]

colnames(MovesAlways90) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways90 <- MovesAlways90[-1, ]

Page91 <- read_html(Link[4])
Moves_table91 <- html_table(html_nodes(Page91, "table"))
Stats91 <- Moves_table91[[3]]
MovesBase91 <- Moves_table91[[5]]
MovesAllCompat91 <- Moves_table91[[6]]
MovesAlways91 <- Moves_table91[[7]]

colnames(MovesAllCompat91) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat91 <- MovesAllCompat91[-1, ]

colnames(MovesAlways91) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways91 <- MovesAlways91[-1, ]

Page92 <- read_html(Link[4])
Moves_table92 <- html_table(html_nodes(Page92, "table"))
Stats92 <- Moves_table92[[3]]
MovesBase92 <- Moves_table92[[5]]
MovesAllCompat92 <- Moves_table92[[6]]
MovesAlways92 <- Moves_table92[[7]]

colnames(MovesAllCompat92) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat92 <- MovesAllCompat92[-1, ]

colnames(MovesAlways92) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways92 <- MovesAlways92[-1, ]

Page93 <- read_html(Link[4])
Moves_table93 <- html_table(html_nodes(Page93, "table"))
Stats93 <- Moves_table93[[3]]
MovesBase93 <- Moves_table93[[5]]
MovesAllCompat93 <- Moves_table93[[6]]
MovesAlways93 <- Moves_table93[[7]]

colnames(MovesAllCompat93) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat93 <- MovesAllCompat93[-1, ]

colnames(MovesAlways93) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways93 <- MovesAlways93[-1, ]

Page94 <- read_html(Link[4])
Moves_table94 <- html_table(html_nodes(Page94, "table"))
Stats94 <- Moves_table94[[3]]
MovesBase94 <- Moves_table94[[5]]
MovesAllCompat94 <- Moves_table94[[6]]
MovesAlways94 <- Moves_table94[[7]]

colnames(MovesAllCompat94) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat94 <- MovesAllCompat94[-1, ]

colnames(MovesAlways94) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways94 <- MovesAlways94[-1, ]

Page95 <- read_html(Link[4])
Moves_table95 <- html_table(html_nodes(Page95, "table"))
Stats95 <- Moves_table95[[3]]
MovesBase95 <- Moves_table95[[5]]
MovesAllCompat95 <- Moves_table95[[6]]
MovesAlways95 <- Moves_table95[[7]]

colnames(MovesAllCompat95) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat95 <- MovesAllCompat95[-1, ]

colnames(MovesAlways95) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways95 <- MovesAlways95[-1, ]

Page96 <- read_html(Link[4])
Moves_table96 <- html_table(html_nodes(Page96, "table"))
Stats96 <- Moves_table96[[3]]
MovesBase96 <- Moves_table96[[5]]
MovesAllCompat96 <- Moves_table96[[6]]
MovesAlways96 <- Moves_table96[[7]]

colnames(MovesAllCompat96) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat96 <- MovesAllCompat96[-1, ]

colnames(MovesAlways96) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways96 <- MovesAlways96[-1, ]

Page97 <- read_html(Link[4])
Moves_table97 <- html_table(html_nodes(Page97, "table"))
Stats97 <- Moves_table97[[3]]
MovesBase97 <- Moves_table97[[5]]
MovesAllCompat97 <- Moves_table97[[6]]
MovesAlways97 <- Moves_table97[[7]]

colnames(MovesAllCompat97) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat97 <- MovesAllCompat97[-1, ]

colnames(MovesAlways97) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways97 <- MovesAlways97[-1, ]

Page98 <- read_html(Link[4])
Moves_table98 <- html_table(html_nodes(Page98, "table"))
Stats98 <- Moves_table98[[3]]
MovesBase98 <- Moves_table98[[5]]
MovesAllCompat98 <- Moves_table98[[6]]
MovesAlways98 <- Moves_table98[[7]]

colnames(MovesAllCompat98) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat98 <- MovesAllCompat98[-1, ]

colnames(MovesAlways98) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways98 <- MovesAlways98[-1, ]

Page99 <- read_html(Link[4])
Moves_table99 <- html_table(html_nodes(Page99, "table"))
Stats99 <- Moves_table99[[3]]
MovesBase99 <- Moves_table99[[5]]
MovesAllCompat99 <- Moves_table99[[6]]
MovesAlways99 <- Moves_table99[[7]]

colnames(MovesAllCompat99) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat99 <- MovesAllCompat99[-1, ]

colnames(MovesAlways99) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways99 <- MovesAlways99[-1, ]

Page100 <- read_html(Link[4])
Moves_table100 <- html_table(html_nodes(Page100, "table"))
Stats100 <- Moves_table100[[3]]
MovesBase100 <- Moves_table100[[5]]
MovesAllCompat100 <- Moves_table100[[6]]
MovesAlways100 <- Moves_table100[[7]]

colnames(MovesAllCompat100) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat100 <- MovesAllCompat100[-1, ]

colnames(MovesAlways100) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways100 <- MovesAlways100[-1, ]

Page101 <- read_html(Link[4])
Moves_table101 <- html_table(html_nodes(Page101, "table"))
Stats101 <- Moves_table101[[3]]
MovesBase101 <- Moves_table101[[5]]
MovesAllCompat101 <- Moves_table101[[6]]
MovesAlways101 <- Moves_table101[[7]]

colnames(MovesAllCompat101) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat101 <- MovesAllCompat101[-1, ]

colnames(MovesAlways101) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways101 <- MovesAlways101[-1, ]

Page102 <- read_html(Link[4])
Moves_table102 <- html_table(html_nodes(Page102, "table"))
Stats102 <- Moves_table102[[3]]
MovesBase102 <- Moves_table102[[5]]
MovesAllCompat102 <- Moves_table102[[6]]
MovesAlways102 <- Moves_table102[[7]]

colnames(MovesAllCompat102) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat102 <- MovesAllCompat102[-1, ]

colnames(MovesAlways102) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways102 <- MovesAlways102[-1, ]

Page103 <- read_html(Link[4])
Moves_table103 <- html_table(html_nodes(Page103, "table"))
Stats103 <- Moves_table103[[3]]
MovesBase103 <- Moves_table103[[5]]
MovesAllCompat103 <- Moves_table103[[6]]
MovesAlways103 <- Moves_table103[[7]]

colnames(MovesAllCompat103) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat103 <- MovesAllCompat103[-1, ]

colnames(MovesAlways103) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways103 <- MovesAlways103[-1, ]

Page104 <- read_html(Link[4])
Moves_table104 <- html_table(html_nodes(Page104, "table"))
Stats104 <- Moves_table104[[3]]
MovesBase104 <- Moves_table104[[5]]
MovesAllCompat104 <- Moves_table104[[6]]
MovesAlways104 <- Moves_table104[[7]]

colnames(MovesAllCompat104) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat104 <- MovesAllCompat104[-1, ]

colnames(MovesAlways104) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways104 <- MovesAlways104[-1, ]

Page105 <- read_html(Link[4])
Moves_table105 <- html_table(html_nodes(Page105, "table"))
Stats105 <- Moves_table105[[3]]
MovesBase105 <- Moves_table105[[5]]
MovesAllCompat105 <- Moves_table105[[6]]
MovesAlways105 <- Moves_table105[[7]]

colnames(MovesAllCompat105) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat105 <- MovesAllCompat105[-1, ]

colnames(MovesAlways105) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways105 <- MovesAlways105[-1, ]

Page106 <- read_html(Link[4])
Moves_table106 <- html_table(html_nodes(Page106, "table"))
Stats106 <- Moves_table106[[3]]
MovesBase106 <- Moves_table106[[5]]
MovesAllCompat106 <- Moves_table106[[6]]
MovesAlways106 <- Moves_table106[[7]]

colnames(MovesAllCompat106) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat106 <- MovesAllCompat106[-1, ]

colnames(MovesAlways106) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways106 <- MovesAlways106[-1, ]

Page107 <- read_html(Link[4])
Moves_table107 <- html_table(html_nodes(Page107, "table"))
Stats107 <- Moves_table107[[3]]
MovesBase107 <- Moves_table107[[5]]
MovesAllCompat107 <- Moves_table107[[6]]
MovesAlways107 <- Moves_table107[[7]]

colnames(MovesAllCompat107) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat107 <- MovesAllCompat107[-1, ]

colnames(MovesAlways107) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways107 <- MovesAlways107[-1, ]

Page108 <- read_html(Link[4])
Moves_table108 <- html_table(html_nodes(Page108, "table"))
Stats108 <- Moves_table108[[3]]
MovesBase108 <- Moves_table108[[5]]
MovesAllCompat108 <- Moves_table108[[6]]
MovesAlways108 <- Moves_table108[[7]]

colnames(MovesAllCompat108) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat108 <- MovesAllCompat108[-1, ]

colnames(MovesAlways108) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways108 <- MovesAlways108[-1, ]

Page109 <- read_html(Link[4])
Moves_table109 <- html_table(html_nodes(Page109, "table"))
Stats109 <- Moves_table109[[3]]
MovesBase109 <- Moves_table109[[5]]
MovesAllCompat109 <- Moves_table109[[6]]
MovesAlways109 <- Moves_table109[[7]]

colnames(MovesAllCompat109) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat109 <- MovesAllCompat109[-1, ]

colnames(MovesAlways109) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways109 <- MovesAlways109[-1, ]

Page110 <- read_html(Link[4])
Moves_table110 <- html_table(html_nodes(Page110, "table"))
Stats110 <- Moves_table110[[3]]
MovesBase110 <- Moves_table110[[5]]
MovesAllCompat110 <- Moves_table110[[6]]
MovesAlways110 <- Moves_table110[[7]]

colnames(MovesAllCompat110) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat110 <- MovesAllCompat110[-1, ]

colnames(MovesAlways110) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways110 <- MovesAlways110[-1, ]

Page111 <- read_html(Link[4])
Moves_table111 <- html_table(html_nodes(Page111, "table"))
Stats111 <- Moves_table111[[3]]
MovesBase111 <- Moves_table111[[5]]
MovesAllCompat111 <- Moves_table111[[6]]
MovesAlways111 <- Moves_table111[[7]]

colnames(MovesAllCompat111) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat111 <- MovesAllCompat111[-1, ]

colnames(MovesAlways111) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways111 <- MovesAlways111[-1, ]

Page112 <- read_html(Link[4])
Moves_table112 <- html_table(html_nodes(Page112, "table"))
Stats112 <- Moves_table112[[3]]
MovesBase112 <- Moves_table112[[5]]
MovesAllCompat112 <- Moves_table112[[6]]
MovesAlways112 <- Moves_table112[[7]]

colnames(MovesAllCompat112) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat112 <- MovesAllCompat112[-1, ]

colnames(MovesAlways112) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways112 <- MovesAlways112[-1, ]

Page113 <- read_html(Link[4])
Moves_table113 <- html_table(html_nodes(Page113, "table"))
Stats113 <- Moves_table113[[3]]
MovesBase113 <- Moves_table113[[5]]
MovesAllCompat113 <- Moves_table113[[6]]
MovesAlways113 <- Moves_table113[[7]]

colnames(MovesAllCompat113) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat113 <- MovesAllCompat113[-1, ]

colnames(MovesAlways113) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways113 <- MovesAlways113[-1, ]

Page114 <- read_html(Link[4])
Moves_table114 <- html_table(html_nodes(Page114, "table"))
Stats114 <- Moves_table114[[3]]
MovesBase114 <- Moves_table114[[5]]
MovesAllCompat114 <- Moves_table114[[6]]
MovesAlways114 <- Moves_table114[[7]]

colnames(MovesAllCompat114) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat114 <- MovesAllCompat114[-1, ]

colnames(MovesAlways114) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways114 <- MovesAlways114[-1, ]

Page115 <- read_html(Link[4])
Moves_table115 <- html_table(html_nodes(Page115, "table"))
Stats115 <- Moves_table115[[3]]
MovesBase115 <- Moves_table115[[5]]
MovesAllCompat115 <- Moves_table115[[6]]
MovesAlways115 <- Moves_table115[[7]]

colnames(MovesAllCompat115) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat115 <- MovesAllCompat115[-1, ]

colnames(MovesAlways115) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways115 <- MovesAlways115[-1, ]

Page116 <- read_html(Link[4])
Moves_table116 <- html_table(html_nodes(Page116, "table"))
Stats116 <- Moves_table116[[3]]
MovesBase116 <- Moves_table116[[5]]
MovesAllCompat116 <- Moves_table116[[6]]
MovesAlways116 <- Moves_table116[[7]]

colnames(MovesAllCompat116) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat116 <- MovesAllCompat116[-1, ]

colnames(MovesAlways116) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways116 <- MovesAlways116[-1, ]

Page117 <- read_html(Link[4])
Moves_table117 <- html_table(html_nodes(Page117, "table"))
Stats117 <- Moves_table117[[3]]
MovesBase117 <- Moves_table117[[5]]
MovesAllCompat117 <- Moves_table117[[6]]
MovesAlways117 <- Moves_table117[[7]]

colnames(MovesAllCompat117) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat117 <- MovesAllCompat117[-1, ]

colnames(MovesAlways117) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways117 <- MovesAlways117[-1, ]

Page118 <- read_html(Link[4])
Moves_table118 <- html_table(html_nodes(Page118, "table"))
Stats118 <- Moves_table118[[3]]
MovesBase118 <- Moves_table118[[5]]
MovesAllCompat118 <- Moves_table118[[6]]
MovesAlways118 <- Moves_table118[[7]]

colnames(MovesAllCompat118) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat118 <- MovesAllCompat118[-1, ]

colnames(MovesAlways118) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways118 <- MovesAlways118[-1, ]

Page119 <- read_html(Link[4])
Moves_table119 <- html_table(html_nodes(Page119, "table"))
Stats119 <- Moves_table119[[3]]
MovesBase119 <- Moves_table119[[5]]
MovesAllCompat119 <- Moves_table119[[6]]
MovesAlways119 <- Moves_table119[[7]]

colnames(MovesAllCompat119) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat119 <- MovesAllCompat119[-1, ]

colnames(MovesAlways119) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways119 <- MovesAlways119[-1, ]

Page120 <- read_html(Link[4])
Moves_table120 <- html_table(html_nodes(Page120, "table"))
Stats120 <- Moves_table120[[3]]
MovesBase120 <- Moves_table120[[5]]
MovesAllCompat120 <- Moves_table120[[6]]
MovesAlways120 <- Moves_table120[[7]]

colnames(MovesAllCompat120) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat120 <- MovesAllCompat120[-1, ]

colnames(MovesAlways120) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways120 <- MovesAlways120[-1, ]

Page121 <- read_html(Link[4])
Moves_table121 <- html_table(html_nodes(Page121, "table"))
Stats121 <- Moves_table121[[3]]
MovesBase121 <- Moves_table121[[5]]
MovesAllCompat121 <- Moves_table121[[6]]
MovesAlways121 <- Moves_table121[[7]]

colnames(MovesAllCompat121) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat121 <- MovesAllCompat121[-1, ]

colnames(MovesAlways121) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways121 <- MovesAlways121[-1, ]

Page122 <- read_html(Link[4])
Moves_table122 <- html_table(html_nodes(Page122, "table"))
Stats122 <- Moves_table122[[3]]
MovesBase122 <- Moves_table122[[5]]
MovesAllCompat122 <- Moves_table122[[6]]
MovesAlways122 <- Moves_table122[[7]]

colnames(MovesAllCompat122) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat122 <- MovesAllCompat122[-1, ]

colnames(MovesAlways122) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways122 <- MovesAlways122[-1, ]

Page123 <- read_html(Link[4])
Moves_table123 <- html_table(html_nodes(Page123, "table"))
Stats123 <- Moves_table123[[3]]
MovesBase123 <- Moves_table123[[5]]
MovesAllCompat123 <- Moves_table123[[6]]
MovesAlways123 <- Moves_table123[[7]]

colnames(MovesAllCompat123) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat123 <- MovesAllCompat123[-1, ]

colnames(MovesAlways123) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways123 <- MovesAlways123[-1, ]

Page124 <- read_html(Link[4])
Moves_table124 <- html_table(html_nodes(Page124, "table"))
Stats124 <- Moves_table124[[3]]
MovesBase124 <- Moves_table124[[5]]
MovesAllCompat124 <- Moves_table124[[6]]
MovesAlways124 <- Moves_table124[[7]]

colnames(MovesAllCompat124) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat124 <- MovesAllCompat124[-1, ]

colnames(MovesAlways124) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways124 <- MovesAlways124[-1, ]

Page125 <- read_html(Link[4])
Moves_table125 <- html_table(html_nodes(Page125, "table"))
Stats125 <- Moves_table125[[3]]
MovesBase125 <- Moves_table125[[5]]
MovesAllCompat125 <- Moves_table125[[6]]
MovesAlways125 <- Moves_table125[[7]]

colnames(MovesAllCompat125) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat125 <- MovesAllCompat125[-1, ]

colnames(MovesAlways125) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways125 <- MovesAlways125[-1, ]

Page126 <- read_html(Link[4])
Moves_table126 <- html_table(html_nodes(Page126, "table"))
Stats126 <- Moves_table126[[3]]
MovesBase126 <- Moves_table126[[5]]
MovesAllCompat126 <- Moves_table126[[6]]
MovesAlways126 <- Moves_table126[[7]]

colnames(MovesAllCompat126) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat126 <- MovesAllCompat126[-1, ]

colnames(MovesAlways126) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways126 <- MovesAlways126[-1, ]

Page127 <- read_html(Link[4])
Moves_table127 <- html_table(html_nodes(Page127, "table"))
Stats127 <- Moves_table127[[3]]
MovesBase127 <- Moves_table127[[5]]
MovesAllCompat127 <- Moves_table127[[6]]
MovesAlways127 <- Moves_table127[[7]]

colnames(MovesAllCompat127) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat127 <- MovesAllCompat127[-1, ]

colnames(MovesAlways127) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways127 <- MovesAlways127[-1, ]

Page128 <- read_html(Link[4])
Moves_table128 <- html_table(html_nodes(Page128, "table"))
Stats128 <- Moves_table128[[3]]
MovesBase128 <- Moves_table128[[5]]
MovesAllCompat128 <- Moves_table128[[6]]
MovesAlways128 <- Moves_table128[[7]]

colnames(MovesAllCompat128) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat128 <- MovesAllCompat128[-1, ]

colnames(MovesAlways128) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways128 <- MovesAlways128[-1, ]

Page129 <- read_html(Link[4])
Moves_table129 <- html_table(html_nodes(Page129, "table"))
Stats129 <- Moves_table129[[3]]
MovesBase129 <- Moves_table129[[5]]
MovesAllCompat129 <- Moves_table129[[6]]
MovesAlways129 <- Moves_table129[[7]]

colnames(MovesAllCompat129) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat129 <- MovesAllCompat129[-1, ]

colnames(MovesAlways129) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways129 <- MovesAlways129[-1, ]

Page130 <- read_html(Link[4])
Moves_table130 <- html_table(html_nodes(Page130, "table"))
Stats130 <- Moves_table130[[3]]
MovesBase3 <- Moves_table130[[5]]
MovesAllCompat130 <- Moves_table130[[6]]
MovesAlways130 <- Moves_table130[[7]]

colnames(MovesAllCompat130) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat130 <- MovesAllCompat130[-1, ]

colnames(MovesAlways130) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways130 <- MovesAlways130[-1, ]

Page131 <- read_html(Link[4])
Moves_table131 <- html_table(html_nodes(Page131, "table"))
Stats131 <- Moves_table131[[3]]
MovesBase131 <- Moves_table131[[5]]
MovesAllCompat131 <- Moves_table131[[6]]
MovesAlways131 <- Moves_table131[[7]]

colnames(MovesAllCompat131) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat131 <- MovesAllCompat131[-1, ]

colnames(MovesAlways131) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways131 <- MovesAlways131[-1, ]

Page132 <- read_html(Link[4])
Moves_table132 <- html_table(html_nodes(Page132, "table"))
Stats132 <- Moves_table132[[3]]
MovesBase132 <- Moves_table132[[5]]
MovesAllCompat132 <- Moves_table132[[6]]
MovesAlways132 <- Moves_table132[[7]]

colnames(MovesAllCompat132) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat132 <- MovesAllCompat132[-1, ]

colnames(MovesAlways132) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways132 <- MovesAlways132[-1, ]

Page133 <- read_html(Link[4])
Moves_table133 <- html_table(html_nodes(Page133, "table"))
Stats133 <- Moves_table133[[3]]
MovesBase133 <- Moves_table133[[5]]
MovesAllCompat133 <- Moves_table133[[6]]
MovesAlways133 <- Moves_table133[[7]]

colnames(MovesAllCompat133) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat133 <- MovesAllCompat133[-1, ]

colnames(MovesAlways133) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways133 <- MovesAlways133[-1, ]

Page134 <- read_html(Link[4])
Moves_table134 <- html_table(html_nodes(Page134, "table"))
Stats134 <- Moves_table134[[3]]
MovesBase134 <- Moves_table134[[5]]
MovesAllCompat134 <- Moves_table134[[6]]
MovesAlways134 <- Moves_table134[[7]]

colnames(MovesAllCompat134) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat134 <- MovesAllCompat134[-1, ]

colnames(MovesAlways134) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways134 <- MovesAlways134[-1, ]

Page135 <- read_html(Link[4])
Moves_table135 <- html_table(html_nodes(Page135, "table"))
Stats135 <- Moves_table135[[3]]
MovesBase135 <- Moves_table135[[5]]
MovesAllCompat135 <- Moves_table135[[6]]
MovesAlways135 <- Moves_table135[[7]]

colnames(MovesAllCompat135) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat135 <- MovesAllCompat135[-1, ]

colnames(MovesAlways135) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways135 <- MovesAlways135[-1, ]

Page136 <- read_html(Link[4])
Moves_table136 <- html_table(html_nodes(Page136, "table"))
Stats136 <- Moves_table136[[3]]
MovesBase136 <- Moves_table136[[5]]
MovesAllCompat136 <- Moves_table136[[6]]
MovesAlways136 <- Moves_table136[[7]]

colnames(MovesAllCompat136) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat136 <- MovesAllCompat136[-1, ]

colnames(MovesAlways136) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways136 <- MovesAlways136[-1, ]

Page137 <- read_html(Link[4])
Moves_table137 <- html_table(html_nodes(Page137, "table"))
Stats137 <- Moves_table137[[3]]
MovesBase137 <- Moves_table137[[5]]
MovesAllCompat137 <- Moves_table137[[6]]
MovesAlways137 <- Moves_table137[[7]]

colnames(MovesAllCompat137) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat137 <- MovesAllCompat137[-1, ]

colnames(MovesAlways137) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways137 <- MovesAlways137[-1, ]

Page138 <- read_html(Link[4])
Moves_table138 <- html_table(html_nodes(Page138, "table"))
Stats138 <- Moves_table138[[3]]
MovesBase138 <- Moves_table138[[5]]
MovesAllCompat138 <- Moves_table138[[6]]
MovesAlways138 <- Moves_table138[[7]]

colnames(MovesAllCompat138) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat138 <- MovesAllCompat138[-1, ]

colnames(MovesAlways138) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways138 <- MovesAlways138[-1, ]

Page139 <- read_html(Link[4])
Moves_table139 <- html_table(html_nodes(Page139, "table"))
Stats139 <- Moves_table139[[3]]
MovesBase139 <- Moves_table139[[5]]
MovesAllCompat139 <- Moves_table139[[6]]
MovesAlways139 <- Moves_table139[[7]]

colnames(MovesAllCompat139) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat139 <- MovesAllCompat139[-1, ]

colnames(MovesAlways139) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways139 <- MovesAlways139[-1, ]

Page140 <- read_html(Link[4])
Moves_table140 <- html_table(html_nodes(Page140, "table"))
Stats140 <- Moves_table140[[3]]
MovesBase140 <- Moves_table140[[5]]
MovesAllCompat140 <- Moves_table140[[6]]
MovesAlways140 <- Moves_table140[[7]]

colnames(MovesAllCompat140) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAllCompat140 <- MovesAllCompat140[-1, ]

colnames(MovesAlways140) <- c("Method", "Move", "Type", "Category", "Power", "Accuracy", "AP")
MovesAlways140 <- MovesAlways140[-1, ]


# Define UI for application that draws a histogram
ui <- fluidPage(
  # Application title
  titlePanel("Cassette Beasts Moveset Creator"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId = "Beast1", "Choose a Beast:", choices = NameList, selected = "Springheel"),
      textInput("Nickname", "Set A Nickname:"),
      sliderInput("Grade", "Tape Grade", min = 0, max = 5, step = 1, value = 5),
      selectInput(inputId = "Type1", "Choose a Bootleg Type:", choices = c("Non Bootleg", "Beast", "Air", "Astral", "Earth", "Fire", "Ice", "Lightning", "Metal", "Plant", "Plastic", "Poison", "Water", "Glass", "Glitter")),
      uiOutput('move1'),
      uiOutput('move2'),
      uiOutput('move3'),
      uiOutput('move4'),
      uiOutput('move5'),
      uiOutput('move6'),
      uiOutput('move7'),
      uiOutput('move8'),
                  width = 6
      ),
      
      # Show a plot of the generated distribution
      mainPanel(textOutput("textname1"), 
        textOutput("nickname1"), textOutput("grade1"),textOutput("textmoves11"), textOutput("textmoves12"), 
        textOutput("textmoves13"), textOutput("textmoves14"), textOutput("textmoves15"), 
        textOutput("textmoves16"), textOutput("textmoves17"), textOutput("textmoves18"), width = 6
      )
    )
  )
  
  
  # Define server logic required to draw a histogram
  server <- function(input, output, session) {
    moveInput <- reactive({
      if (input$Beast1 == NameList[1]) vars <- inner_join(Moves_table, full_join(MKMovesAlways[,-1], MKMovesAllCompat[,-1]))
      if (input$Beast1 == NameList[2]) vars <- inner_join(Moves_table, full_join(MovesAlways1[,-1], MovesAllCompat1[,-1]))
      if (input$Beast1 == NameList[3]) vars <- inner_join(Moves_table, full_join(MovesAlways2[,-1], MovesAllCompat2[,-1]))
      if (input$Beast1 == NameList[4]) vars <- inner_join(Moves_table, full_join(MovesAlways3[,-1], MovesAllCompat3[,-1]))
      if (input$Beast1 == NameList[5]) vars <- inner_join(Moves_table, full_join(MovesAlways4[,-1], MovesAllCompat4[,-1]))
      if (input$Beast1 == NameList[6]) vars <- inner_join(Moves_table, full_join(MovesAlways5[,-1], MovesAllCompat5[,-1]))
      if (input$Beast1 == NameList[7]) vars <- inner_join(Moves_table, full_join(MovesAlways6[,-1], MovesAllCompat6[,-1]))
      if (input$Beast1 == NameList[8]) vars <- inner_join(Moves_table, full_join(MovesAlways7[,-1], MovesAllCompat7[,-1]))
      if (input$Beast1 == NameList[9]) vars <- inner_join(Moves_table, full_join(MovesAlways8[,-1], MovesAllCompat8[,-1]))
      if (input$Beast1 == NameList[10]) vars <- inner_join(Moves_table, full_join(MovesAlways9[,-1], MovesAllCompat9[,-1]))
      if (input$Beast1 == NameList[11]) vars <- inner_join(Moves_table, full_join(MovesAlways10[,-1], MovesAllCompat10[,-1]))
      if (input$Beast1 == NameList[12]) vars <- inner_join(Moves_table, full_join(MovesAlways11[,-1], MovesAllCompat11[,-1]))
      if (input$Beast1 == NameList[13]) vars <- inner_join(Moves_table, full_join(MovesAlways12[,-1], MovesAllCompat12[,-1]))
      if (input$Beast1 == NameList[14]) vars <- inner_join(Moves_table, full_join(MovesAlways13[,-1], MovesAllCompat13[,-1]))
      if (input$Beast1 == NameList[15]) vars <- inner_join(Moves_table, full_join(MovesAlways14[,-1], MovesAllCompat14[,-1]))
      if (input$Beast1 == NameList[16]) vars <- inner_join(Moves_table, full_join(MovesAlways15[,-1], MovesAllCompat15[,-1]))
      if (input$Beast1 == NameList[17]) vars <- inner_join(Moves_table, full_join(MovesAlways16[,-1], MovesAllCompat16[,-1]))
      if (input$Beast1 == NameList[18]) vars <- inner_join(Moves_table, full_join(MovesAlways17[,-1], MovesAllCompat17[,-1]))
      if (input$Beast1 == NameList[19]) vars <- inner_join(Moves_table, full_join(MovesAlways18[,-1], MovesAllCompat18[,-1]))
      if (input$Beast1 == NameList[20]) vars <- inner_join(Moves_table, full_join(MovesAlways19[,-1], MovesAllCompat19[,-1]))
      if (input$Beast1 == NameList[21]) vars <- inner_join(Moves_table, full_join(MovesAlways20[,-1], MovesAllCompat20[,-1]))
      if (input$Beast1 == NameList[22]) vars <- inner_join(Moves_table, full_join(MovesAlways21[,-1], MovesAllCompat21[,-1]))
      if (input$Beast1 == NameList[23]) vars <- inner_join(Moves_table, full_join(MovesAlways22[,-1], MovesAllCompat22[,-1]))
      if (input$Beast1 == NameList[24]) vars <- inner_join(Moves_table, full_join(MovesAlways23[,-1], MovesAllCompat23[,-1]))
      if (input$Beast1 == NameList[25]) vars <- inner_join(Moves_table, full_join(MovesAlways24[,-1], MovesAllCompat24[,-1]))
      if (input$Beast1 == NameList[26]) vars <- inner_join(Moves_table, full_join(MovesAlways25[,-1], MovesAllCompat25[,-1]))
      if (input$Beast1 == NameList[27]) vars <- inner_join(Moves_table, full_join(MovesAlways26[,-1], MovesAllCompat26[,-1]))
      if (input$Beast1 == NameList[28]) vars <- inner_join(Moves_table, full_join(MovesAlways27[,-1], MovesAllCompat27[,-1]))
      if (input$Beast1 == NameList[29]) vars <- inner_join(Moves_table, full_join(MovesAlways28[,-1], MovesAllCompat28[,-1]))
      if (input$Beast1 == NameList[30]) vars <- inner_join(Moves_table, full_join(MovesAlways29[,-1], MovesAllCompat29[,-1]))
      if (input$Beast1 == NameList[31]) vars <- inner_join(Moves_table, full_join(MovesAlways30[,-1], MovesAllCompat30[,-1]))
      if (input$Beast1 == NameList[32]) vars <- inner_join(Moves_table, full_join(MovesAlways31[,-1], MovesAllCompat31[,-1]))
      if (input$Beast1 == NameList[33]) vars <- inner_join(Moves_table, full_join(MovesAlways32[,-1], MovesAllCompat32[,-1]))
      if (input$Beast1 == NameList[34]) vars <- inner_join(Moves_table, full_join(MovesAlways33[,-1], MovesAllCompat33[,-1]))
      if (input$Beast1 == NameList[35]) vars <- inner_join(Moves_table, full_join(MovesAlways34[,-1], MovesAllCompat34[,-1]))
      if (input$Beast1 == NameList[36]) vars <- inner_join(Moves_table, full_join(MovesAlways35[,-1], MovesAllCompat35[,-1]))
      if (input$Beast1 == NameList[37]) vars <- inner_join(Moves_table, full_join(MovesAlways36[,-1], MovesAllCompat36[,-1]))
      if (input$Beast1 == NameList[38]) vars <- inner_join(Moves_table, full_join(MovesAlways37[,-1], MovesAllCompat37[,-1]))
      if (input$Beast1 == NameList[39]) vars <- inner_join(Moves_table, full_join(MovesAlways38[,-1], MovesAllCompat38[,-1]))
      if (input$Beast1 == NameList[40]) vars <- inner_join(Moves_table, full_join(MovesAlways39[,-1], MovesAllCompat39[,-1]))
      if (input$Beast1 == NameList[41]) vars <- inner_join(Moves_table, full_join(MovesAlways40[,-1], MovesAllCompat40[,-1]))
      if (input$Beast1 == NameList[42]) vars <- inner_join(Moves_table, full_join(MovesAlways41[,-1], MovesAllCompat41[,-1]))
      if (input$Beast1 == NameList[43]) vars <- inner_join(Moves_table, full_join(MovesAlways42[,-1], MovesAllCompat42[,-1]))
      if (input$Beast1 == NameList[44]) vars <- inner_join(Moves_table, full_join(MovesAlways43[,-1], MovesAllCompat43[,-1]))
      if (input$Beast1 == NameList[45]) vars <- inner_join(Moves_table, full_join(MovesAlways44[,-1], MovesAllCompat44[,-1]))
      if (input$Beast1 == NameList[46]) vars <- inner_join(Moves_table, full_join(MovesAlways45[,-1], MovesAllCompat45[,-1]))
      if (input$Beast1 == NameList[47]) vars <- inner_join(Moves_table, full_join(MovesAlways46[,-1], MovesAllCompat46[,-1]))
      if (input$Beast1 == NameList[48]) vars <- inner_join(Moves_table, full_join(MovesAlways47[,-1], MovesAllCompat47[,-1]))
      if (input$Beast1 == NameList[49]) vars <- inner_join(Moves_table, full_join(MovesAlways48[,-1], MovesAllCompat48[,-1]))
      if (input$Beast1 == NameList[50]) vars <- inner_join(Moves_table, full_join(MovesAlways49[,-1], MovesAllCompat49[,-1]))
      if (input$Beast1 == NameList[51]) vars <- inner_join(Moves_table, full_join(MovesAlways50[,-1], MovesAllCompat50[,-1]))
      if (input$Beast1 == NameList[52]) vars <- inner_join(Moves_table, full_join(MovesAlways51[,-1], MovesAllCompat51[,-1]))
      if (input$Beast1 == NameList[53]) vars <- inner_join(Moves_table, full_join(MovesAlways52[,-1], MovesAllCompat52[,-1]))
      if (input$Beast1 == NameList[54]) vars <- inner_join(Moves_table, full_join(MovesAlways53[,-1], MovesAllCompat53[,-1]))
      if (input$Beast1 == NameList[55]) vars <- inner_join(Moves_table, full_join(MovesAlways54[,-1], MovesAllCompat54[,-1]))
      if (input$Beast1 == NameList[56]) vars <- inner_join(Moves_table, full_join(MovesAlways55[,-1], MovesAllCompat55[,-1]))
      if (input$Beast1 == NameList[57]) vars <- inner_join(Moves_table, full_join(MovesAlways56[,-1], MovesAllCompat56[,-1]))
      if (input$Beast1 == NameList[58]) vars <- inner_join(Moves_table, full_join(MovesAlways57[,-1], MovesAllCompat57[,-1]))
      if (input$Beast1 == NameList[59]) vars <- inner_join(Moves_table, full_join(MovesAlways58[,-1], MovesAllCompat58[,-1]))
      if (input$Beast1 == NameList[60]) vars <- inner_join(Moves_table, full_join(MovesAlways59[,-1], MovesAllCompat59[,-1]))
      if (input$Beast1 == NameList[61]) vars <- inner_join(Moves_table, full_join(MovesAlways60[,-1], MovesAllCompat60[,-1]))
      if (input$Beast1 == NameList[62]) vars <- inner_join(Moves_table, full_join(MovesAlways61[,-1], MovesAllCompat61[,-1]))
      if (input$Beast1 == NameList[63]) vars <- inner_join(Moves_table, full_join(MovesAlways62[,-1], MovesAllCompat62[,-1]))
      if (input$Beast1 == NameList[64]) vars <- inner_join(Moves_table, full_join(MovesAlways63[,-1], MovesAllCompat63[,-1]))
      if (input$Beast1 == NameList[65]) vars <- inner_join(Moves_table, full_join(MovesAlways64[,-1], MovesAllCompat64[,-1]))
      if (input$Beast1 == NameList[66]) vars <- inner_join(Moves_table, full_join(MovesAlways65[,-1], MovesAllCompat65[,-1]))
      if (input$Beast1 == NameList[67]) vars <- inner_join(Moves_table, full_join(MovesAlways66[,-1], MovesAllCompat66[,-1]))
      if (input$Beast1 == NameList[68]) vars <- inner_join(Moves_table, full_join(MovesAlways67[,-1], MovesAllCompat67[,-1]))
      if (input$Beast1 == NameList[69]) vars <- inner_join(Moves_table, full_join(MovesAlways68[,-1], MovesAllCompat68[,-1]))
      if (input$Beast1 == NameList[70]) vars <- inner_join(Moves_table, full_join(MovesAlways69[,-1], MovesAllCompat69[,-1]))
      if (input$Beast1 == NameList[71]) vars <- inner_join(Moves_table, full_join(MovesAlways70[,-1], MovesAllCompat70[,-1]))
      if (input$Beast1 == NameList[72]) vars <- inner_join(Moves_table, full_join(MovesAlways71[,-1], MovesAllCompat71[,-1]))
      if (input$Beast1 == NameList[73]) vars <- inner_join(Moves_table, full_join(MovesAlways72[,-1], MovesAllCompat72[,-1]))
      if (input$Beast1 == NameList[74]) vars <- inner_join(Moves_table, full_join(MovesAlways73[,-1], MovesAllCompat73[,-1]))
      if (input$Beast1 == NameList[75]) vars <- inner_join(Moves_table, full_join(MovesAlways74[,-1], MovesAllCompat74[,-1]))
      if (input$Beast1 == NameList[76]) vars <- inner_join(Moves_table, full_join(MovesAlways75[,-1], MovesAllCompat75[,-1]))
      if (input$Beast1 == NameList[77]) vars <- inner_join(Moves_table, full_join(MovesAlways76[,-1], MovesAllCompat76[,-1]))
      if (input$Beast1 == NameList[78]) vars <- inner_join(Moves_table, full_join(MovesAlways77[,-1], MovesAllCompat77[,-1]))
      if (input$Beast1 == NameList[79]) vars <- inner_join(Moves_table, full_join(MovesAlways78[,-1], MovesAllCompat78[,-1]))
      if (input$Beast1 == NameList[80]) vars <- inner_join(Moves_table, full_join(MovesAlways79[,-1], MovesAllCompat79[,-1]))
      if (input$Beast1 == NameList[81]) vars <- inner_join(Moves_table, full_join(MovesAlways80[,-1], MovesAllCompat80[,-1]))
      if (input$Beast1 == NameList[82]) vars <- inner_join(Moves_table, full_join(MovesAlways81[,-1], MovesAllCompat81[,-1]))
      if (input$Beast1 == NameList[83]) vars <- inner_join(Moves_table, full_join(MovesAlways82[,-1], MovesAllCompat82[,-1]))
      if (input$Beast1 == NameList[84]) vars <- inner_join(Moves_table, full_join(MovesAlways83[,-1], MovesAllCompat83[,-1]))
      if (input$Beast1 == NameList[85]) vars <- inner_join(Moves_table, full_join(MovesAlways84[,-1], MovesAllCompat84[,-1]))
      if (input$Beast1 == NameList[86]) vars <- inner_join(Moves_table, full_join(MovesAlways85[,-1], MovesAllCompat85[,-1]))
      if (input$Beast1 == NameList[87]) vars <- inner_join(Moves_table, full_join(MovesAlways86[,-1], MovesAllCompat86[,-1]))
      if (input$Beast1 == NameList[88]) vars <- inner_join(Moves_table, full_join(MovesAlways87[,-1], MovesAllCompat87[,-1]))
      if (input$Beast1 == NameList[89]) vars <- inner_join(Moves_table, full_join(MovesAlways88[,-1], MovesAllCompat88[,-1]))
      if (input$Beast1 == NameList[90]) vars <- inner_join(Moves_table, full_join(MovesAlways89[,-1], MovesAllCompat89[,-1]))
      if (input$Beast1 == NameList[91]) vars <- inner_join(Moves_table, full_join(MovesAlways90[,-1], MovesAllCompat90[,-1]))
      if (input$Beast1 == NameList[92]) vars <- inner_join(Moves_table, full_join(MovesAlways91[,-1], MovesAllCompat91[,-1]))
      if (input$Beast1 == NameList[93]) vars <- inner_join(Moves_table, full_join(MovesAlways92[,-1], MovesAllCompat92[,-1]))
      if (input$Beast1 == NameList[94]) vars <- inner_join(Moves_table, full_join(MovesAlways93[,-1], MovesAllCompat93[,-1]))
      if (input$Beast1 == NameList[95]) vars <- inner_join(Moves_table, full_join(MovesAlways94[,-1], MovesAllCompat94[,-1]))
      if (input$Beast1 == NameList[96]) vars <- inner_join(Moves_table, full_join(MovesAlways95[,-1], MovesAllCompat95[,-1]))
      if (input$Beast1 == NameList[97]) vars <- inner_join(Moves_table, full_join(MovesAlways96[,-1], MovesAllCompat96[,-1]))
      if (input$Beast1 == NameList[98]) vars <- inner_join(Moves_table, full_join(MovesAlways97[,-1], MovesAllCompat97[,-1]))
      if (input$Beast1 == NameList[99]) vars <- inner_join(Moves_table, full_join(MovesAlways98[,-1], MovesAllCompat98[,-1]))
      if (input$Beast1 == NameList[100]) vars <- inner_join(Moves_table, full_join(MovesAlways99[,-1], MovesAllCompat99[,-1]))
      if (input$Beast1 == NameList[101]) vars <- inner_join(Moves_table, full_join(MovesAlways100[,-1], MovesAllCompat100[,-1]))
      if (input$Beast1 == NameList[102]) vars <- inner_join(Moves_table, full_join(MovesAlways101[,-1], MovesAllCompat101[,-1]))
      if (input$Beast1 == NameList[103]) vars <- inner_join(Moves_table, full_join(MovesAlways102[,-1], MovesAllCompat102[,-1]))
      if (input$Beast1 == NameList[104]) vars <- inner_join(Moves_table, full_join(MovesAlways103[,-1], MovesAllCompat103[,-1]))
      if (input$Beast1 == NameList[105]) vars <- inner_join(Moves_table, full_join(MovesAlways104[,-1], MovesAllCompat104[,-1]))
      if (input$Beast1 == NameList[106]) vars <- inner_join(Moves_table, full_join(MovesAlways105[,-1], MovesAllCompat105[,-1]))
      if (input$Beast1 == NameList[107]) vars <- inner_join(Moves_table, full_join(MovesAlways106[,-1], MovesAllCompat106[,-1]))
      if (input$Beast1 == NameList[108]) vars <- inner_join(Moves_table, full_join(MovesAlways107[,-1], MovesAllCompat107[,-1]))
      if (input$Beast1 == NameList[109]) vars <- inner_join(Moves_table, full_join(MovesAlways108[,-1], MovesAllCompat108[,-1]))
      if (input$Beast1 == NameList[110]) vars <- inner_join(Moves_table, full_join(MovesAlways109[,-1], MovesAllCompat109[,-1]))
      if (input$Beast1 == NameList[111]) vars <- inner_join(Moves_table, full_join(MovesAlways110[,-1], MovesAllCompat110[,-1]))
      if (input$Beast1 == NameList[112]) vars <- inner_join(Moves_table, full_join(MovesAlways111[,-1], MovesAllCompat111[,-1]))
      if (input$Beast1 == NameList[113]) vars <- inner_join(Moves_table, full_join(MovesAlways112[,-1], MovesAllCompat112[,-1]))
      if (input$Beast1 == NameList[114]) vars <- inner_join(Moves_table, full_join(MovesAlways113[,-1], MovesAllCompat113[,-1]))
      if (input$Beast1 == NameList[115]) vars <- inner_join(Moves_table, full_join(MovesAlways114[,-1], MovesAllCompat114[,-1]))
      if (input$Beast1 == NameList[116]) vars <- inner_join(Moves_table, full_join(MovesAlways115[,-1], MovesAllCompat115[,-1]))
      if (input$Beast1 == NameList[117]) vars <- inner_join(Moves_table, full_join(MovesAlways116[,-1], MovesAllCompat116[,-1]))
      if (input$Beast1 == NameList[118]) vars <- inner_join(Moves_table, full_join(MovesAlways117[,-1], MovesAllCompat117[,-1]))
      if (input$Beast1 == NameList[119]) vars <- inner_join(Moves_table, full_join(MovesAlways118[,-1], MovesAllCompat118[,-1]))
      if (input$Beast1 == NameList[120]) vars <- inner_join(Moves_table, full_join(MovesAlways119[,-1], MovesAllCompat119[,-1]))
      if (input$Beast1 == NameList[121]) vars <- inner_join(Moves_table, full_join(MovesAlways120[,-1], MovesAllCompat120[,-1]))
      if (input$Beast1 == NameList[122]) vars <- inner_join(Moves_table, full_join(MovesAlways121[,-1], MovesAllCompat121[,-1]))
      if (input$Beast1 == NameList[123]) vars <- inner_join(Moves_table, full_join(MovesAlways122[,-1], MovesAllCompat122[,-1]))
      if (input$Beast1 == NameList[124]) vars <- inner_join(Moves_table, full_join(MovesAlways123[,-1], MovesAllCompat123[,-1]))
      if (input$Beast1 == NameList[125]) vars <- inner_join(Moves_table, full_join(MovesAlways124[,-1], MovesAllCompat124[,-1]))
      if (input$Beast1 == NameList[126]) vars <- inner_join(Moves_table, full_join(MovesAlways125[,-1], MovesAllCompat125[,-1]))
      if (input$Beast1 == NameList[127]) vars <- inner_join(Moves_table, full_join(MovesAlways126[,-1], MovesAllCompat126[,-1]))
      if (input$Beast1 == NameList[128]) vars <- inner_join(Moves_table, full_join(MovesAlways127[,-1], MovesAllCompat127[,-1]))
      if (input$Beast1 == NameList[129]) vars <- inner_join(Moves_table, full_join(MovesAlways128[,-1], MovesAllCompat128[,-1]))
      if (input$Beast1 == NameList[130]) vars <- inner_join(Moves_table, full_join(MovesAlways129[,-1], MovesAllCompat129[,-1]))
      if (input$Beast1 == NameList[131]) vars <- inner_join(Moves_table, full_join(MovesAlways130[,-1], MovesAllCompat130[,-1]))
      if (input$Beast1 == NameList[132]) vars <- inner_join(Moves_table, full_join(MovesAlways131[,-1], MovesAllCompat131[,-1]))
      if (input$Beast1 == NameList[133]) vars <- inner_join(Moves_table, full_join(MovesAlways132[,-1], MovesAllCompat132[,-1]))
      if (input$Beast1 == NameList[134]) vars <- inner_join(Moves_table, full_join(MovesAlways133[,-1], MovesAllCompat133[,-1]))
      if (input$Beast1 == NameList[135]) vars <- inner_join(Moves_table, full_join(MovesAlways134[,-1], MovesAllCompat134[,-1]))
      if (input$Beast1 == NameList[136]) vars <- inner_join(Moves_table, full_join(MovesAlways135[,-1], MovesAllCompat135[,-1]))
      if (input$Beast1 == NameList[137]) vars <- inner_join(Moves_table, full_join(MovesAlways136[,-1], MovesAllCompat136[,-1]))
      if (input$Beast1 == NameList[138]) vars <- inner_join(Moves_table, full_join(MovesAlways137[,-1], MovesAllCompat137[,-1]))
      if (input$Beast1 == NameList[139]) vars <- inner_join(Moves_table, full_join(MovesAlways138[,-1], MovesAllCompat138[,-1]))
      if (input$Beast1 == NameList[140]) vars <- inner_join(Moves_table, full_join(MovesAlways139[,-1], MovesAllCompat139[,-1]))
      if (input$Beast1 == NameList[141]) vars <- inner_join(Moves_table, full_join(MovesAlways140[,-1], MovesAllCompat140[,-1]))
      as.list(vars[,1])})
    typeInput <- reactive({
      if (input$Type1 == "Non Bootleg") vars2 <- MKMovesBootleg %>% filter(Type == "Non Bootleg")
      if (input$Type1 == "Beast") vars2 <- MKMovesBootleg %>% filter(Type == "Beast")
      if (input$Type1 == "Fire") vars2 <- MKMovesBootleg %>% filter(Type == "Fire")
      if (input$Type1 == "Air") vars2 <- MKMovesBootleg %>% filter(Type == "Air")
      if (input$Type1 == "Astral") vars2 <- MKMovesBootleg %>% filter(Type == "Astral")
      if (input$Type1 == "Earth") vars2 <- MKMovesBootleg %>% filter(Type == "Earth")
      if (input$Type1 == "Lightning") vars2 <- MKMovesBootleg %>% filter(Type == "Lightning")
      if (input$Type1 == "Metal") vars2 <- MKMovesBootleg %>% filter(Type == "Metal")
      if (input$Type1 == "Plant") vars2 <- MKMovesBootleg %>% filter(Type == "Plant")
      if (input$Type1 == "Plastic") vars2 <- MKMovesBootleg %>% filter(Type == "Plastic")
      if (input$Type1 == "Poison") vars2 <- MKMovesBootleg %>% filter(Type == "Poison")
      if (input$Type1 == "Water") vars2 <- MKMovesBootleg %>% filter(Type == "Water")
      if (input$Type1 == "Glass") vars2 <- MKMovesBootleg %>% filter(Type == "Glass")
      if (input$Type1 == "Glitter") vars2 <- MKMovesBootleg %>% filter(Type == "Glitter")
      as.list(vars2[,1])
    })
output$move1 <- renderUI({
  selectInput(inputId = "Moves11", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
output$move2 <- renderUI({
  selectInput(inputId = "Moves12", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
output$move3 <- renderUI({
  selectInput(inputId = "Moves13", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
output$move4 <- renderUI({
  selectInput(inputId = "Moves14", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
output$move5 <- renderUI({
  selectInput(inputId = "Moves15", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
output$move6 <- renderUI({
  selectInput(inputId = "Moves16", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
output$move7 <- renderUI({
  selectInput(inputId = "Moves17", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
output$move8 <- renderUI({
  selectInput(inputId = "Moves18", "Select your Moves", choices = c("<Empty Slot>", moveInput(), typeInput()))
})
    output$name2 <- renderText(input$Beast1)
    output$textname1 <- renderText({ifelse(input$Type1 == "Non Bootleg", input$Beast1 ,paste(input$Beast1," (",input$Type1,")" ,sep = ""))})
    output$nickname1 <- renderText({ifelse(input$Nickname == "", "", paste("Nickname: ", input$Nickname, sep = ""))})
    output$grade1 <- renderText({paste("Grade: ", input$Grade, sep = "")})
    output$textmoves11 <- renderText({paste("- ", input$Moves11, sep = "")})
    output$textmoves12 <- renderText({paste("- ", input$Moves12, sep = "")})
    output$textmoves13 <- renderText({paste("- ", input$Moves13, sep = "")})
    output$textmoves14 <- renderText({paste("- ", input$Moves14, sep = "")})
    output$textmoves15 <- renderText({paste("- ", input$Moves15, sep = "")})
    output$textmoves16 <- renderText({paste("- ", input$Moves16, sep = "")})
    output$textmoves17 <- renderText({paste("- ", input$Moves17, sep = "")})
    output$textmoves18 <- renderText({paste("- ", input$Moves18, sep = "")})
  }
  
  # Run the application 
  shinyApp(ui = ui, server = server)
  